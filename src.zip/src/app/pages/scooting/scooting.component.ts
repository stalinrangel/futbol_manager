import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scooting',
  templateUrl: './scooting.component.html',
  styleUrls: ['./scooting.component.scss']
})
export class ScootingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
